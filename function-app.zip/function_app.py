"""
Financi MCP Server - Financial Analysis Tools
Azure Function App implementation for Model Context Protocol server.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Union
import asyncio
from datetime import datetime, timedelta
import aiohttp

import azure.functions as func
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    CallToolRequest,
    CallToolResult,
    ListToolsRequest,
    ListToolsResult,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FinanciMCPServer:
    """Financi MCP Server for financial analysis tools."""
    
    def __init__(self):
        self.server = Server("financi")
        self.setup_tools()
        
    def setup_tools(self):
        """Register all available tools."""
        
        @self.server.list_tools()
        async def handle_list_tools() -> list[Tool]:
            """List all available financial analysis tools."""
            return [
                Tool(
                    name="get_stock_price",
                    description="Get current stock price and basic information for a given ticker symbol",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "symbol": {
                                "type": "string",
                                "description": "Stock ticker symbol (e.g., AAPL, MSFT, TSLA)"
                            }
                        },
                        "required": ["symbol"]
                    }
                ),
                Tool(
                    name="get_stock_history",
                    description="Get historical stock price data for technical analysis",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "symbol": {
                                "type": "string",
                                "description": "Stock ticker symbol"
                            },
                            "period": {
                                "type": "string",
                                "description": "Time period for historical data",
                                "enum": ["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "ytd", "max"],
                                "default": "1mo"
                            }
                        },
                        "required": ["symbol"]
                    }
                ),
                Tool(
                    name="get_crypto_price",
                    description="Get current cryptocurrency price and market data",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "symbol": {
                                "type": "string",
                                "description": "Cryptocurrency symbol (e.g., BTC, ETH, ADA)"
                            },
                            "vs_currency": {
                                "type": "string",
                                "description": "Currency to compare against",
                                "default": "usd"
                            }
                        },
                        "required": ["symbol"]
                    }
                ),
                Tool(
                    name="calculate_technical_indicators",
                    description="Calculate technical indicators for stock analysis (RSI, MACD, Moving Averages)",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "symbol": {
                                "type": "string",
                                "description": "Stock ticker symbol"
                            },
                            "indicators": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "enum": ["rsi", "macd", "sma_20", "sma_50", "ema_12", "ema_26"]
                                },
                                "description": "List of technical indicators to calculate"
                            },
                            "period": {
                                "type": "string",
                                "description": "Time period for analysis",
                                "default": "3mo"
                            }
                        },
                        "required": ["symbol", "indicators"]
                    }
                ),
                Tool(
                    name="get_financial_ratios",
                    description="Get key financial ratios and metrics for fundamental analysis",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "symbol": {
                                "type": "string",
                                "description": "Stock ticker symbol"
                            }
                        },
                        "required": ["symbol"]
                    }
                ),
                Tool(
                    name="portfolio_analysis",
                    description="Analyze a portfolio of stocks and cryptocurrencies",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "holdings": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "symbol": {"type": "string"},
                                        "quantity": {"type": "number"},
                                        "type": {"type": "string", "enum": ["stock", "crypto"]}
                                    },
                                    "required": ["symbol", "quantity", "type"]
                                },
                                "description": "List of portfolio holdings"
                            }
                        },
                        "required": ["holdings"]
                    }
                )
            ]
            
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: dict) -> list[TextContent | ImageContent | EmbeddedResource]:
            """Handle tool calls."""
            try:
                if name == "get_stock_price":
                    result = await self._get_stock_price(arguments.get("symbol"))
                elif name == "get_stock_history":
                    result = await self._get_stock_history(
                        arguments.get("symbol"),
                        arguments.get("period", "1mo")
                    )
                elif name == "get_crypto_price":
                    result = await self._get_crypto_price(
                        arguments.get("symbol"),
                        arguments.get("vs_currency", "usd")
                    )
                elif name == "calculate_technical_indicators":
                    result = await self._calculate_technical_indicators(
                        arguments.get("symbol"),
                        arguments.get("indicators"),
                        arguments.get("period", "3mo")
                    )
                elif name == "get_financial_ratios":
                    result = await self._get_financial_ratios(arguments.get("symbol"))
                elif name == "portfolio_analysis":
                    result = await self._portfolio_analysis(arguments.get("holdings"))
                else:
                    return [TextContent(type="text", text=f"Unknown tool: {name}")]
                    
                return [TextContent(type="text", text=json.dumps(result, indent=2))]
                
            except Exception as e:
                logger.error(f"Error in tool {name}: {str(e)}")
                return [TextContent(type="text", text=f"Error: {str(e)}")]
    
    async def _get_stock_price(self, symbol: str) -> dict:
        """Get current stock price using Alpha Vantage API."""
        api_key = os.getenv("ALPHA_VANTAGE_API_KEY")
        if not api_key:
            return {"error": "Alpha Vantage API key not configured"}
            
        url = f"https://www.alphavantage.co/query"
        params = {
            "function": "GLOBAL_QUOTE",
            "symbol": symbol.upper(),
            "apikey": api_key
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                data = await response.json()
                
                if "Global Quote" in data:
                    quote = data["Global Quote"]
                    return {
                        "symbol": quote.get("01. symbol"),
                        "price": float(quote.get("05. price", 0)),
                        "change": float(quote.get("09. change", 0)),
                        "change_percent": quote.get("10. change percent"),
                        "volume": int(quote.get("06. volume", 0)),
                        "latest_trading_day": quote.get("07. latest trading day"),
                        "previous_close": float(quote.get("08. previous close", 0))
                    }
                else:
                    return {"error": f"No data found for symbol {symbol}"}
    
    async def _get_stock_history(self, symbol: str, period: str) -> dict:
        """Get historical stock data."""
        api_key = os.getenv("ALPHA_VANTAGE_API_KEY")
        if not api_key:
            return {"error": "Alpha Vantage API key not configured"}
        
        # Map period to Alpha Vantage function
        function_map = {
            "1d": "TIME_SERIES_INTRADAY",
            "5d": "TIME_SERIES_DAILY",
            "1mo": "TIME_SERIES_DAILY",
            "3mo": "TIME_SERIES_DAILY",
            "6mo": "TIME_SERIES_DAILY",
            "1y": "TIME_SERIES_DAILY",
            "2y": "TIME_SERIES_WEEKLY",
            "5y": "TIME_SERIES_WEEKLY",
            "10y": "TIME_SERIES_MONTHLY"
        }
        
        function = function_map.get(period, "TIME_SERIES_DAILY")
        url = f"https://www.alphavantage.co/query"
        
        params = {
            "function": function,
            "symbol": symbol.upper(),
            "apikey": api_key
        }
        
        if function == "TIME_SERIES_INTRADAY":
            params["interval"] = "60min"
            
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                data = await response.json()
                
                # Extract time series data based on function
                if "Time Series (Daily)" in data:
                    time_series = data["Time Series (Daily)"]
                elif "Weekly Time Series" in data:
                    time_series = data["Weekly Time Series"]
                elif "Monthly Time Series" in data:
                    time_series = data["Monthly Time Series"]
                elif "Time Series (60min)" in data:
                    time_series = data["Time Series (60min)"]
                else:
                    return {"error": "No historical data found"}
                
                # Convert to list format
                history = []
                for date, values in list(time_series.items())[:100]:  # Limit to 100 data points
                    history.append({
                        "date": date,
                        "open": float(values["1. open"]),
                        "high": float(values["2. high"]),
                        "low": float(values["3. low"]),
                        "close": float(values["4. close"]),
                        "volume": int(values["5. volume"])
                    })
                
                return {
                    "symbol": symbol.upper(),
                    "period": period,
                    "data": history
                }
    
    async def _get_crypto_price(self, symbol: str, vs_currency: str = "usd") -> dict:
        """Get cryptocurrency price using CoinGecko API."""
        url = f"https://api.coingecko.com/api/v3/simple/price"
        params = {
            "ids": symbol.lower(),
            "vs_currencies": vs_currency,
            "include_24hr_change": "true",
            "include_24hr_vol": "true",
            "include_market_cap": "true"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                data = await response.json()
                
                if symbol.lower() in data:
                    crypto_data = data[symbol.lower()]
                    return {
                        "symbol": symbol.upper(),
                        "price": crypto_data.get(vs_currency),
                        "change_24h": crypto_data.get(f"{vs_currency}_24h_change"),
                        "volume_24h": crypto_data.get(f"{vs_currency}_24h_vol"),
                        "market_cap": crypto_data.get(f"{vs_currency}_market_cap"),
                        "vs_currency": vs_currency.upper()
                    }
                else:
                    return {"error": f"No data found for cryptocurrency {symbol}"}
    
    async def _calculate_technical_indicators(self, symbol: str, indicators: list, period: str) -> dict:
        """Calculate technical indicators."""
        # First get historical data
        history_data = await self._get_stock_history(symbol, period)
        
        if "error" in history_data:
            return history_data
            
        prices = [float(day["close"]) for day in history_data["data"]]
        volumes = [int(day["volume"]) for day in history_data["data"]]
        
        results = {"symbol": symbol, "indicators": {}}
        
        for indicator in indicators:
            if indicator == "rsi":
                results["indicators"]["rsi"] = self._calculate_rsi(prices)
            elif indicator == "macd":
                results["indicators"]["macd"] = self._calculate_macd(prices)
            elif indicator == "sma_20":
                results["indicators"]["sma_20"] = self._calculate_sma(prices, 20)
            elif indicator == "sma_50":
                results["indicators"]["sma_50"] = self._calculate_sma(prices, 50)
            elif indicator == "ema_12":
                results["indicators"]["ema_12"] = self._calculate_ema(prices, 12)
            elif indicator == "ema_26":
                results["indicators"]["ema_26"] = self._calculate_ema(prices, 26)
        
        return results
    
    def _calculate_rsi(self, prices: list, period: int = 14) -> float:
        """Calculate RSI (Relative Strength Index)."""
        if len(prices) < period + 1:
            return None
        
        deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
        gains = [delta if delta > 0 else 0 for delta in deltas]
        losses = [-delta if delta < 0 else 0 for delta in deltas]
        
        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period
        
        for i in range(period, len(gains)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        
        if avg_loss == 0:
            return 100
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return round(rsi, 2)
    
    def _calculate_macd(self, prices: list) -> dict:
        """Calculate MACD (Moving Average Convergence Divergence)."""
        if len(prices) < 26:
            return None
        
        ema_12 = self._calculate_ema(prices, 12)
        ema_26 = self._calculate_ema(prices, 26)
        
        if ema_12 is None or ema_26 is None:
            return None
        
        macd_line = ema_12 - ema_26
        
        return {
            "macd_line": round(macd_line, 4),
            "ema_12": round(ema_12, 4),
            "ema_26": round(ema_26, 4)
        }
    
    def _calculate_sma(self, prices: list, period: int) -> float:
        """Calculate Simple Moving Average."""
        if len(prices) < period:
            return None
        return round(sum(prices[-period:]) / period, 4)
    
    def _calculate_ema(self, prices: list, period: int) -> float:
        """Calculate Exponential Moving Average."""
        if len(prices) < period:
            return None
        
        multiplier = 2 / (period + 1)
        ema = prices[0]
        
        for price in prices[1:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
        
        return round(ema, 4)
    
    async def _get_financial_ratios(self, symbol: str) -> dict:
        """Get financial ratios and key metrics."""
        # This would typically use a financial data API
        # For now, return a placeholder structure
        return {
            "symbol": symbol.upper(),
            "ratios": {
                "pe_ratio": "N/A - Requires premium API",
                "pb_ratio": "N/A - Requires premium API", 
                "debt_to_equity": "N/A - Requires premium API",
                "return_on_equity": "N/A - Requires premium API",
                "current_ratio": "N/A - Requires premium API"
            },
            "note": "Financial ratios require premium API access. Consider integrating with Financial Modeling Prep, IEX Cloud, or similar service."
        }
    
    async def _portfolio_analysis(self, holdings: list) -> dict:
        """Analyze portfolio performance and allocation."""
        portfolio_value = 0
        portfolio_details = []
        
        for holding in holdings:
            symbol = holding["symbol"]
            quantity = holding["quantity"]
            asset_type = holding["type"]
            
            if asset_type == "stock":
                price_data = await self._get_stock_price(symbol)
                if "error" not in price_data:
                    current_price = price_data["price"]
                    value = current_price * quantity
                    portfolio_value += value
                    
                    portfolio_details.append({
                        "symbol": symbol,
                        "type": "stock",
                        "quantity": quantity,
                        "current_price": current_price,
                        "value": value,
                        "change_percent": price_data.get("change_percent", "N/A")
                    })
            
            elif asset_type == "crypto":
                price_data = await self._get_crypto_price(symbol)
                if "error" not in price_data:
                    current_price = price_data["price"]
                    value = current_price * quantity
                    portfolio_value += value
                    
                    portfolio_details.append({
                        "symbol": symbol,
                        "type": "crypto",
                        "quantity": quantity,
                        "current_price": current_price,
                        "value": value,
                        "change_24h": price_data.get("change_24h", "N/A")
                    })
        
        # Calculate allocations
        for asset in portfolio_details:
            asset["allocation_percent"] = round((asset["value"] / portfolio_value) * 100, 2) if portfolio_value > 0 else 0
        
        return {
            "total_value": round(portfolio_value, 2),
            "holdings": portfolio_details,
            "diversification": {
                "stock_allocation": round(sum(h["allocation_percent"] for h in portfolio_details if h["type"] == "stock"), 2),
                "crypto_allocation": round(sum(h["allocation_percent"] for h in portfolio_details if h["type"] == "crypto"), 2)
            }
        }

# Azure Function implementation
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

@app.route(route="mcp", auth_level=func.AuthLevel.FUNCTION)
async def mcp_handler(req: func.HttpRequest) -> func.HttpResponse:
    """Azure Function HTTP trigger for MCP server."""
    
    try:
        # Initialize MCP server
        mcp_server = FinanciMCPServer()
        
        # Get request data
        try:
            req_body = req.get_json()
        except ValueError:
            return func.HttpResponse(
                json.dumps({"error": "Invalid JSON in request body"}),
                status_code=400,
                mimetype="application/json"
            )
        
        if not req_body:
            return func.HttpResponse(
                json.dumps({"error": "No JSON data provided"}),
                status_code=400,
                mimetype="application/json"
            )
        
        # Handle MCP protocol messages
        method = req_body.get("method")
        
        if method == "tools/list":
            tools = await mcp_server.server._tool_handlers[method]()
            response = {
                "tools": [tool.model_dump() for tool in tools]
            }
        
        elif method == "tools/call":
            params = req_body.get("params", {})
            tool_name = params.get("name")
            tool_arguments = params.get("arguments", {})
            
            result = await mcp_server.server._tool_handlers["tools/call"](tool_name, tool_arguments)
            response = {
                "content": [content.model_dump() for content in result]
            }
        
        else:
            return func.HttpResponse(
                json.dumps({"error": f"Unsupported method: {method}"}),
                status_code=400,
                mimetype="application/json"
            )
        
        return func.HttpResponse(
            json.dumps(response),
            status_code=200,
            mimetype="application/json"
        )
        
    except Exception as e:
        logger.error(f"Error in MCP handler: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Internal server error: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )

@app.route(route="health", auth_level=func.AuthLevel.ANONYMOUS)
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint."""
    return func.HttpResponse(
        json.dumps({
            "status": "healthy",
            "server": "financi-mcp-server",
            "version": "1.0.0",
            "timestamp": datetime.utcnow().isoformat()
        }),
        status_code=200,
        mimetype="application/json"
    )